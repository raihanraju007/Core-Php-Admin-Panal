<?php
require_once './config/config.php';
session_start();
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
	$email = filter_input(INPUT_POST, 'username');
	$passwd = filter_input(INPUT_POST, 'passwd');
	$remember = filter_input(INPUT_POST, 'remember');
//	$role = 'ROOT';
//	$role_user = 'AGENT';
    $role = array("ROOT", "AGENT", "COMPANY_OWNER", "ADMIN");


    //echo password_verify('admin', '$2y$10$RnDwpen5c8.gtZLaxHEHDOKWY77t/20A4RRkWBsjlPuu7Wmy0HyBu'); exit;

	//Get DB instance.
	$db = getDbInstance();

	$db->where("user_name", $email);

	$row = $db->get('user_accounts');

	if ($db->count >= 1) {

		$db_password = $row[0]['password'];
		$user_id = $row[0]['id'];
		$db_role = $row[0]['user_type'];

		if (password_verify($passwd, $db_password)) {


            for($i = 0; $i<=3; $i++)
            {
                if($role[$i] === $db_role)
                {
                    $_SESSION['user_logged_in'] = TRUE;
//			$_SESSION['admin_type'] = $row[0]['type'];

                    if ($remember) {

                        $series_id = randomString(16);
                        $remember_token = getSecureRandomToken(20);
                        $encryted_remember_token = password_hash($remember_token,PASSWORD_DEFAULT);


                        $expiry_time = date('Y-m-d H:i:s', strtotime(' + 30 days'));

                        $expires = strtotime($expiry_time);

                        setcookie('series_id', $series_id, $expires, "/");
                        setcookie('remember_token', $remember_token, $expires, "/");

                        $db = getDbInstance();
                        $db->where ('id',$user_id);

                        $update_remember = array(
                            'series_id'=> $series_id,
                            'remember_token' => $encryted_remember_token,
                            'expires' =>$expiry_time
                        );
                        $db->update("user_accounts",$update_remember);
                    }
                    if($role[$i] == "ROOT")
                    {
                        header('Location:index.php');

                    }
                    else if($role[$i] == "COMPANY_OWNER")
                    {
                        header('Location:view/company_owner/index.php');

                    }
                    else if($role[$i] == "ADMIN")
                    {
                        header('Location:view/admin_user/admin_user.php');

                    }
                    else
                        {
                        header('Location:view/Agent/index.php');

                    }



                }
            }

//		    else if($role[1] === $db_role)
//		    {
//                $_SESSION['user_logged_in'] = TRUE;
////			$_SESSION['admin_type'] = $row[0]['type'];
//
//                if ($remember) {
//
//                    $series_id = randomString(16);
//                    $remember_token = getSecureRandomToken(20);
//                    $encryted_remember_token = password_hash($remember_token,PASSWORD_DEFAULT);
//
//
//                    $expiry_time = date('Y-m-d H:i:s', strtotime(' + 30 days'));
//
//                    $expires = strtotime($expiry_time);
//
//                    setcookie('series_id', $series_id, $expires, "/");
//                    setcookie('remember_token', $remember_token, $expires, "/");
//
//                    $db = getDbInstance();
//                    $db->where ('id',$user_id);
//
//                    $update_remember = array(
//                        'series_id'=> $series_id,
//                        'remember_token' => $encryted_remember_token,
//                        'expires' =>$expiry_time
//                    );
//                    $db->update("user_accounts",$update_remember);
//                }
//                header('Location:view/agent_user.php');
//
//            }
			//Authentication successfull redirect user

		} else {
		
			$_SESSION['login_failure'] = "Invalid user name or password";
			header('Location:login.php');
		}

		exit;
	} else {
		$_SESSION['login_failure'] = "Invalid user name or password";
		header('Location:login.php');
		exit;
	}

}
else {
	die('Method Not allowed');
}