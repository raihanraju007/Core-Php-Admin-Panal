<?php
include('include/header.php');
include('include/topbar.php');
?>

<body id="page-top">

<!-- Page Wrapper -->
<div id="wrapper">
    <?php
    include('include/sidebar.php');
    ?>
</body>

<?php
include('include/script.php');
include ('include/footer.php');
?>
