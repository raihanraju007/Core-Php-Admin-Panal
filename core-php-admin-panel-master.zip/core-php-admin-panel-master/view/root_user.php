<?php
session_start();
require_once './config/config.php';
require_once 'includes/auth_validate.php';

//Get DB instance. function is defined in config.php
$db = getDbInstance();
//echo 'Hello Form root User';


include_once('includes/header.php');






include_once('includes/footer.php');

?>