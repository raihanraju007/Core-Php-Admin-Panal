<?php
include('include/header.php');
include('include/topbar.php');
?>


<?php
//including the database connection file
$con = mysqli_connect('localhost','root','');
mysqli_select_db($con,'corephpadmin');


if(isset($_POST['product_brand']))
{

    $product_id = $_POST['product_id'];
    $brand_id = $_POST['brand_id'];


        //insert data to database
        $sql = "INSERT INTO product_brand(product_id, brand_id) 
        VALUES ('$product_id','$brand_id')";


        $rslt = mysqli_query($con,$sql);

        if($rslt)
        {

            //display success message
            echo "<font color='green'>product brand added successfully.";
            echo "<br/><a href='view.php'>View Result</a>";
        }else{
            echo mysqli_error($con);
        }

}
?>

<?php

$products = "SELECT *
            FROM products";
$brands = "SELECT *
            FROM brands";
//$result="SELECT * FROM products ORDER BY id DESC";
$rslt=mysqli_query($con,$products);
$rslt_update=mysqli_query($con,$brands);
?>



<body id="page-top">

<!-- Page Wrapper -->
<div id="wrapper">
    <?php
    include('include/sidebar.php');
    ?>
    <div style="margin:auto; width: 80%;" class="col-md-5">
        <form action="add_product_brand.php" method="post">


            <?php
            echo "<select  name='product_id'>";
            echo "<option>Select</option>";

            while($product = mysqli_fetch_array($rslt))
            {


                echo "<option  value=".$product['id']."> ".$product['product_name']."</option>";


            }

            echo "</select>";
            echo "<br>";

            echo "<select  name='brand_id'>";
            echo "<option>Select</option>";

            while($brand = mysqli_fetch_array($rslt_update))
            {


                echo "<option  value=".$brand['id']."> ".$brand['brand_name']."</option>";

            }
            echo "</select>";



            ?>


            <button type="submit" name="product_brand" class="btn btn-primary">Submit</button>
        </form></div>
</div>

</body>


<?php
include('include/script.php');
include ('include/footer.php');
?>
