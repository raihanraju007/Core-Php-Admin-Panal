<?php
include('include/header.php');
include('include/topbar.php');
?>


<?php
//including the database connection file
$con = mysqli_connect('localhost','root','');
mysqli_select_db($con,'corephpadmin');


if(isset($_POST['Product_category']))
{

    $product_category = $_POST['Product_category'];
    $product_name = $_POST['Product_name'];
    $product_desc = $_POST['Product_description'];
    $product_generic = $_POST['Product_generic'];
    $product_slug = $_POST['Product_slug'];
    $product_status = $_POST['Status'];
    $price = $_POST['Price'];
    $featured = $_POST['Featured'];
    $specification = $_POST['Specification'];
    $contract = $_POST['Contract'];
    $link = $_POST['Link'];


//    $user_id =$_SESSION['user_id'];


    // checking empty fields
    if(empty($product_category) || empty($product_name) || empty($product_desc) || empty($product_generic) || empty($product_slug)
        || empty($product_status) || empty($price)  || empty($featured)  || empty($specification) || empty($contract) || empty($link))
    {

        if(empty($product_category)) {
            echo "<font color='red'>category field is empty.</font><br/>";
        }

        if(empty($product_name)) {
            echo "<font color='red'>name field is empty.</font><br/>";
        }

        if(empty($product_desc)) {
            echo "<font color='red'>description field is empty.</font><br/>";
        }
        if(empty($product_generic)) {
            echo "<font color='red'>generic name field is empty.</font><br/>";
        }

        if(empty($product_slug)) {
            echo "<font color='red'>slug field is empty.</font><br/>";
        }
        if(empty($product_status)) {
            echo "<font color='red'>Status field is empty.</font><br/>";
        }
        if(empty($price)) {
            echo "<font color='red'>Price field is empty.</font><br/>";
        }
        if(empty($featured)) {
            echo "<font color='red'>Featured field is empty.</font><br/>";
        }
        if(empty($specification )) {
            echo "<font color='red'>Specification  field is empty.</font><br/>";
        }
        if(empty($contract )) {
            echo "<font color='red'>contract field is empty.</font><br/>";
        }
        if(empty($link )) {
            echo "<font color='red'>Link field is empty.</font><br/>";
        }

    } else {
        // if all the fields are filled (not empty)

        //insert data to database
        $sql = "INSERT INTO products(product_category, product_name, product_description,generic_name,slug,status,price,featured,specification,contract,link ) 
        VALUES ('$product_category','$product_name','$product_desc','$product_generic','$product_slug','$product_status','$price','$featured','$specification','$contract','$link')";


        $rslt = mysqli_query($con,$sql);

        if($rslt)
        {

            //display success message
            echo "<font color='green'>Data added successfully.";
            echo "<br/><a href='view.php'>View Result</a>";
        }else{
            echo mysqli_error($con);
        }
    }
}
?>


<body id="page-top">

<!-- Page Wrapper -->
<div id="wrapper">
    <?php
    include('include/sidebar.php');
    ?>
    <div style="margin:auto; width: 80%;" class="col-md-5">
        <form action="add_product.php" method="post">
            <div class="form-group">
                <label for="product_category">Product Category</label>
                <input type="text" class="form-control" id="product_category" name="Product_category" aria-describedby="emailHelp" placeholder="Enter category">
            </div>
            <div class="form-group">
                <label for="product_name">Product Name</label>
                <input type="text" class="form-control" id="product_name" name="Product_name" aria-describedby="emailHelp" placeholder="Enter product name">
            </div>
            <div class="form-group">
                <label for="product_description">Product Description</label>
                <input type="text" class="form-control" id="product_description" name="Product_description" aria-describedby="emailHelp" placeholder="Enter product description">
            </div>
            <div class="form-group">
                <label for="product_generic">Generic Name</label>
                <input type="text" class="form-control" id="product_generic" name="Product_generic"  aria-describedby="emailHelp" placeholder="Enter generic name">
            </div>
            <div class="form-group">
                <label for="product_slug">Slug Name</label>
                <input type="text" class="form-control" id="product_slug" name="Product_slug" aria-describedby="emailHelp" placeholder="Enter slug name">
            </div>
            <div class="form-group">
                <label for="exampleFormControlSelect1">Status</label>
                <select class="form-control" id="exampleFormControlSelect1" name="Status">
                    <option>Select</option>
                    <option value="ACTIVE">ACTIVE</option>
                    <option value="INACTIVE">INACTIVE</option>
                    <option value="PENDING">PENDING</option>
                    <option VALUE="DELETED">DELETED</option>
                </select>
            </div>

            <div class="form-group">
                <label for="price">Price</label>
                <input type="text" class="form-control" id="price" name="Price" aria-describedby="emailHelp" placeholder="Enter Price">
            </div>

            <div class="form-group">
                <label for="featured">Featured</label>
                <input type="text" class="form-control" id="featured" name="Featured" aria-describedby="emailHelp" placeholder="Enter Featured">
            </div>

            <div class="form-group">
                <label for="specification">Specification</label>
                <input type="text" class="form-control" id="specification" name="Specification" aria-describedby="emailHelp" placeholder="Enter Specification">
            </div>

            <div class="form-group">
                <label for="contract">Contract</label>
                <input type="text" class="form-control" id="contract" name="Contract" aria-describedby="emailHelp" placeholder="Enter Contract">
            </div>

            <div class="form-group">
                <label for="link">Link</label>
                <input type="text" class="form-control" id="link" name="Link" aria-describedby="emailHelp" placeholder="Enter Link">
            </div>



            <div class="form-group form-check">
                <input type="checkbox" class="form-check-input" id="exampleCheck1">
                <label class="form-check-label" for="exampleCheck1">Check me out</label>
            </div>
            <button type="submit" class="btn btn-primary">Submit</button>
        </form></div>
    </div>

</body>


<?php
include('include/script.php');
include ('include/footer.php');
?>
