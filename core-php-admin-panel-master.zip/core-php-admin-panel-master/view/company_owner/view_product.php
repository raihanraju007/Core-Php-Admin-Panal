<?php
include('include/header.php');
include('include/topbar.php');
?>



<?php
//including the database connection file
$con=mysqli_connect('localhost','root','');
mysqli_select_db($con,'corephpadmin');


if(isset($_POST['search']))
{

    $search = $_POST['search'];



//    $product_id = " SELECT * FROM products WHERE product_name like '%".$search."%' OR product_category ='%".$search."%'";
    $result = "SELECT product_category, p.id as `p_id`, product_name,product_description,generic_name,p.slug,p.status,featured,specification,contract,link,price,product_pic
             FROM products p
             JOIN gallery g on g.product_id = p.id
          WHERE product_name like '%".$search."%' OR product_category ='%".$search."%'
            ORDER by p.id";
//    $search_result_product_id = mysqli_query($con,$result);

//    echo $search_result_product_id;




}else {
    $result = "SELECT product_category, p.id as `p_id`, product_name,product_description,generic_name,p.slug,p.status,featured,specification,contract,link,price,product_pic
            FROM products p
            JOIN gallery g on g.product_id = p.id
            ORDER by p.id";

}

//fetching data in descending order (lastest entry first)
//$result = mysql_query("SELECT * FROM users ORDER BY id DESC"); // mysql_query is deprecated





//JOIN product_brand b on p.id = b.product_id
//$result="SELECT * FROM products ORDER BY id DESC";
$rslt = mysqli_query($con,$result);
if($rslt)
{
    echo 'query executed';
}
else
    {
        echo mysqli_error($con);

}
// using mysqli_query instead
?>


<body id="page-top">

<!-- Page Wrapper -->
<div id="wrapper">
    <?php
    include('include/sidebar.php');
    ?>
    <div style="margin: auto;" class="col-md-12">
        <div class="card shadow mb-4">
            <div class="card-header py-3">
                <h6 class="m-0 font-weight-bold text-primary">DataTables Example</h6>
            </div>
            <div class="card-body" style="margin: auto;" >
                <div class="table-responsive">
                    <div id="dataTable_wrapper" class="dataTables_wrapper dt-bootstrap4"><div class="row">
                            <div class="col-sm-12 col-md-6"><div class="dataTables_length" id="dataTable_length"><label>Show <select name="dataTable_length" aria-controls="dataTable" class="custom-select custom-select-sm form-control form-control-sm">
                                            <option value="10">10</option><option value="25">25</option>
                                            <option value="50">50</option><option value="100">100</option></select> entries</label></div></div>
                            <div class="col-sm-12 col-md-6"><div id="dataTable_filter" class="dataTables_filter">
                                    <label>Search:

                                            <form action="view_product.php" method="post">
                                                <input type="search" name="search" class="form-control form-control-sm" placeholder="" aria-controls="dataTable">
                                                <input type="submit" value="search"/>

                                            </form>



                                    </label>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-12">
                                <table class="table table-bordered dataTable" id="dataTable" width="100%" cellspacing="0" role="grid" aria-describedby="dataTable_info" style="width: 100%;">
                                    <thead>
                                    <tr role="row">
                                        <th class="sorting_asc" tabindex="0" aria-controls="dataTable" rowspan="1" colspan="1" aria-sort="ascending" aria-label="Name: activate to sort column descending" style="width: 159px;">Product Category</th>
                                        <th class="sorting" tabindex="0" aria-controls="dataTable" rowspan="1" colspan="1" aria-label="Position: activate to sort column ascending" style="width: 90px;">Product Name</th>
                                        <th class="sorting" tabindex="0" aria-controls="dataTable" rowspan="1" colspan="1" aria-label="Office: activate to sort column ascending" style="width: 90px;">Product Description</th>
                                        <th class="sorting" tabindex="0" aria-controls="dataTable" rowspan="1" colspan="1" aria-label="Age: activate to sort column ascending" style="width: 51px;">Generic</th>
                                        <th class="sorting" tabindex="0" aria-controls="dataTable" rowspan="1" colspan="1" aria-label="Start date: activate to sort column ascending" style="width: 108px;">Slug</th>
                                        <th class="sorting" tabindex="0" aria-controls="dataTable" rowspan="1" colspan="1" aria-label="Salary: activate to sort column ascending" style="width: 98px;">Status</th>
                                        <th class="sorting" tabindex="0" aria-controls="dataTable" rowspan="1" colspan="1" aria-label="Salary: activate to sort column ascending" style="width: 98px;">Price</th>
                                        <th class="sorting" tabindex="0" aria-controls="dataTable" rowspan="1" colspan="1" aria-label="Salary: activate to sort column ascending" style="width: 98px;">Feature</th>
                                        <th class="sorting" tabindex="0" aria-controls="dataTable" rowspan="1" colspan="1" aria-label="Salary: activate to sort column ascending" style="width: 98px;">Specification</th>
                                        <th class="sorting" tabindex="0" aria-controls="dataTable" rowspan="1" colspan="1" aria-label="Salary: activate to sort column ascending" style="width: 98px;">Contract</th>
                                        <th class="sorting" tabindex="0" aria-controls="dataTable" rowspan="1" colspan="1" aria-label="Salary: activate to sort column ascending" style="width: 98px;">Link</th>
                                        <th class="sorting" tabindex="0" aria-controls="dataTable" rowspan="1" colspan="1" aria-label="Salary: activate to sort column ascending" style="width: 98px;">Brand</th>

                                        <th class="sorting" tabindex="0" aria-controls="dataTable" rowspan="1" colspan="1" aria-label="Salary: activate to sort column ascending" style="width: 98px;">Image</th>
                                        <th class="sorting" tabindex="0" aria-controls="dataTable" rowspan="1" colspan="1" aria-label="Salary: activate to sort column ascending" style="width: 98px;">Action</th>
                                    </tr>


                                    </thead>

                                    <tbody>
                                    <?php
                                    //while($res = mysql_fetch_array($result)) { // mysql_fetch_array is deprecated, we need to use mysqli_fetch_array
                                    while($res = mysqli_fetch_array($rslt)) {
                                        echo "<tr>";
                                        echo "<td>".$res['product_category']."</td>";
                                        echo "<td>".$res['product_name']."</td>";
                                        echo "<td>".$res['product_description']."</td>";
                                        echo "<td>".$res['generic_name']."</td>";
                                        echo "<td>".$res['slug']."</td>";
                                        echo "<td>".$res['status']."</td>";
                                        echo "<td>".$res['price']."</td>";
                                        echo "<td>".$res['featured']."</td>";
                                        echo "<td>".$res['specification']."</td>";
                                        echo "<td>".$res['contract']."</td>";
                                        echo "<td>".$res['link']."</td>";

                                        $query = "select * from brands b, products p, product_brand pb 
                                                    where b.id = pb.brand_id and pb.product_id = p.id and p.id = ".$res['p_id'];
                                        $br= mysqli_query($con,$query);

                                        $brand = mysqli_fetch_assoc($br);



                                        echo "<td>".$brand['brand_name']."</td>";
                                       echo "<td><img alt='not found' class='img-thumbnail'  src='images/".$res['product_pic']."'/> </td>";


                                        echo "<td><a href=\"edit_product.php?id=$res[p_id]\">Edit</a> | <a href=\"delete_product.php?id=$res[p_id]\" onClick=\"return confirm('Are you sure you want to delete?')\">Delete</a></td>";
                                    }
                                    ?>

                               </tbody>
                                </table></div></div><div class="row"><div class="col-sm-12 col-md-5"><div class="dataTables_info" id="dataTable_info" role="status" aria-live="polite">Showing 1 to 10 of 57 entries</div></div><div class="col-sm-12 col-md-7"><div class="dataTables_paginate paging_simple_numbers" id="dataTable_paginate"><ul class="pagination"><li class="paginate_button page-item previous disabled" id="dataTable_previous"><a href="#" aria-controls="dataTable" data-dt-idx="0" tabindex="0" class="page-link">Previous</a></li><li class="paginate_button page-item active"><a href="#" aria-controls="dataTable" data-dt-idx="1" tabindex="0" class="page-link">1</a></li><li class="paginate_button page-item "><a href="#" aria-controls="dataTable" data-dt-idx="2" tabindex="0" class="page-link">2</a></li><li class="paginate_button page-item "><a href="#" aria-controls="dataTable" data-dt-idx="3" tabindex="0" class="page-link">3</a></li><li class="paginate_button page-item "><a href="#" aria-controls="dataTable" data-dt-idx="4" tabindex="0" class="page-link">4</a></li><li class="paginate_button page-item "><a href="#" aria-controls="dataTable" data-dt-idx="5" tabindex="0" class="page-link">5</a></li><li class="paginate_button page-item "><a href="#" aria-controls="dataTable" data-dt-idx="6" tabindex="0" class="page-link">6</a></li><li class="paginate_button page-item next" id="dataTable_next"><a href="#" aria-controls="dataTable" data-dt-idx="7" tabindex="0" class="page-link">Next</a></li></ul></div></div></div></div>
                </div>
            </div>
        </div>
    </div>

</div>

</body>


<?php
include('include/script.php');
include ('include/footer.php');
?>
