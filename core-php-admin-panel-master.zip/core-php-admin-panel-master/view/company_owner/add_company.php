<?php
include('include/header.php');
include('include/topbar.php');
?>


<?php
//including the database connection file
$con = mysqli_connect('localhost','root','');
mysqli_select_db($con,'corephpadmin');


if(isset($_POST['Company_type']))
{

    $company_type = $_POST['Company_type'];
    $company_name = $_POST['Company_name'];
    $company_address = $_POST['Company_address'];
    $company_phone = $_POST['Company_phone'];
    $company_category = $_POST['Company_category'];
    $slug = $_POST['Slug'];
    $status = $_POST['Status'];


//    $user_id =$_SESSION['user_id'];


    // checking empty fields
    if(empty($company_type) || empty($company_name) || empty($company_address) || empty($company_phone) || empty($company_category) || empty($slug)|| empty($status) )
    {

        if(empty($company_type)) {
            echo "<font color='red'>Company Type field is empty.</font><br/>";
        }

        if(empty($company_name)) {
            echo "<font color='red'>Company Name field is empty.</font><br/>";
        }

        if(empty($company_address)) {
            echo "<font color='red'>Company Address field is empty.</font><br/>";
        }
        if(empty($company_phone)) {
            echo "<font color='red'>Company Phone field is empty.</font><br/>";
        }

        if(empty($company_category)) {
            echo "<font color='red'>Company Category field is empty.</font><br/>";
        }

        if(empty($slug)) {
            echo "<font color='red'>Slug field is empty.</font><br/>";
        }

        if(empty($status)) {
            echo "<font color='red'>Status field is empty.</font><br/>";
        }

    } else {
        // if all the fields are filled (not empty)

        //insert data to database
        $sql = "INSERT INTO companies(company_type, company_name, company_address, company_phone, company_category,slug,status) 
        VALUES ('$company_type','$company_name','$company_address','$company_phone','$company_category','$slug', '$status')";


        $rslt = mysqli_query($con,$sql);

        if($rslt)
        {

            //display success message
            echo "<font color='green'>Data added successfully.";
            echo "<br/><a href='view_company.php'>View Result</a>";
        }else{
            echo mysqli_error($con);
        }
    }
}
?>


<body id="page-top">

<!-- Page Wrapper -->
<div id="wrapper">
    <?php
    include('include/sidebar.php');
    ?>
    <div style="margin:auto; width: 80%;" class="col-md-5">
        <form action="add_company.php" method="post">
            <div class="form-group">
                <label for="company_type">Company Type</label>
                <input type="text" class="form-control" id="company_type" name="Company_type" aria-describedby="emailHelp" placeholder="Enter Company Type">
            </div>
            <div class="form-group">
                <label for="company_name">Company Name</label>
                <input type="text" class="form-control" id="product_name" name="Company_name" aria-describedby="emailHelp" placeholder="Enter Company name">
            </div>
            <div class="form-group">
                <label for="company_address">Company Address</label>
                <input type="text" class="form-control" id="company_address" name="Company_address" aria-describedby="emailHelp" placeholder="Enter Company Address">
            </div>
            <div class="form-group">
                <label for="company_phone">Company Phone</label>
                <input type="text" class="form-control" id="company_phone" name="Company_phone"  aria-describedby="emailHelp" placeholder="Enter Company Phone">

            </div>
            <div class="form-group">
                <label for="company_phone">Company Category</label>
                <input type="text" class="form-control" id="company_category" name="Company_category"  aria-describedby="emailHelp" placeholder="Company Category">
            </div>

            <div class="form-group">
                <label for="product_slug">Slug Name</label>
                <input type="text" class="form-control" id="slug" name="Slug" aria-describedby="emailHelp" placeholder="Enter slug name">
            </div>
            <div class="form-group">
                <label for="exampleFormControlSelect1">Status</label>
                <select class="form-control" id="exampleFormControlSelect1" name="Status">
                    <option>Select</option>
                    <option value="ACTIVE">ACTIVE</option>
                    <option value="INACTIVE">INACTIVE</option>
                    <option VALUE="DELETED">DELETED</option>
                    <option VALUE="SUSPENDED">SUSPENDED</option>
                </select>
            </div>



            <div class="form-group form-check">
                <input type="checkbox" class="form-check-input" id="exampleCheck1">
                <label class="form-check-label" for="exampleCheck1">Check me out</label>
            </div>
            <button type="submit" class="btn btn-primary">Submit</button>
        </form></div>
</div>

</body>


<?php
include('include/script.php');
include ('include/footer.php');
?>
