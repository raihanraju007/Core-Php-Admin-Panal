<?php
include('include/header.php');
include('include/topbar.php');
?>


<?php
//including the database connection file
$con = mysqli_connect('localhost','root','');
mysqli_select_db($con,'corephpadmin');


if(isset($_POST['Product_category']))
{

    $product_category = $_POST['Product_category'];
    $product_name = $_POST['Product_name'];
    $product_desc = $_POST['Product_description'];
    $product_generic = $_POST['Product_generic'];
    $product_slug = $_POST['Product_slug'];
    $product_status = $_POST['Status'];


//    $user_id =$_SESSION['user_id'];


    // checking empty fields
    if(empty($product_category) || empty($product_name) || empty($product_desc) || empty($product_generic) || empty($product_slug) )
    {

        if(empty($product_category)) {
            echo "<font color='red'>category field is empty.</font><br/>";
        }

        if(empty($product_name)) {
            echo "<font color='red'>name field is empty.</font><br/>";
        }

        if(empty($product_desc)) {
            echo "<font color='red'>description field is empty.</font><br/>";
        }
        if(empty($product_generic)) {
            echo "<font color='red'>generic name field is empty.</font><br/>";
        }

        if(empty($product_slug)) {
            echo "<font color='red'>slug field is empty.</font><br/>";
        }

    } else {
        // if all the fields are filled (not empty)

        //insert data to database
        $sql = "INSERT INTO products (product_category, product_name, product_description,generic_name,slug,status) VALUES ('$product_category','$product_name','$product_desc','$product_generic','$product_slug','$product_status')";


        $rslt = mysqli_query($con,$sql);

        if($rslt)
        {

            //display success message
            echo "<font color='green'>Data added successfully.";
            echo "<br/><a href='view.php'>View Result</a>";
        }else{
            echo mysqli_error($con);
        }
    }
}
?>
<?php

$result="SELECT id,product_name FROM products ORDER BY id";
$rslt = mysqli_query($con,$result);

?>


<?php

if(isset($_POST) && !empty($_FILES['product_image']['name']))
{


//    $name = $_FILES['product_image']['name'];
    $product_id = $_POST['product_id'];
//    $ext = pathinfo($name, PATHINFO_EXTENSION);
//    $image_name = time().".".$ext;
//    $tmp = $_FILES['product_image']['tmp_name'];

    $tmp_name = $_FILES["product_image"]["tmp_name"];
    // basename() may prevent filesystem traversal attacks;
    // further validation/sanitation of the filename may be appropriate
    $name = basename($_FILES["product_image"]["name"]);
   // move_uploaded_file($tmp_name, "$uploads_dir/$name");

    if(move_uploaded_file($tmp_name, 'images/'.$name)){


        $sql = "INSERT INTO gallery (product_pic,product_id) VALUES ('".$name."','$product_id')";
        $rslt = mysqli_query($con,$sql);
        if($rslt)
        {
            echo "Image Uploaded successfully.";
         }
        else
        {
            echo mysqli_error($con);


        }


    }else{
        $_SESSION['error'] = 'image uploading failed';
        echo 'image uploading failed';
       // header("Location: http://localhost:8000");
    }
}
else{
    $_SESSION['error'] = 'Please Select Image or Write title';
  ///  header("Location: http://localhost:8000");
}


?>


<body id="page-top">

<!-- Page Wrapper -->
<div id="wrapper">
    <?php
    include('include/sidebar.php');
    ?>
    <div style="margin:auto; width: 80%;" class="col-md-5">
        <form action="add_gallery.php" method="post" enctype="multipart/form-data">
            <div class="form-group">
                <label for="name">Photos Name</label>
                <input type="text" class="form-control" id="name" name="Name" aria-describedby="emailHelp" placeholder="Enter Photo Name">
            </div>
            <?php
            echo "<select  name='product_id'>";
            echo "<option>Select</option>";

            //while($res = mysql_fetch_array($result)) { // mysql_fetch_array is deprecated, we need to use mysqli_fetch_array
            while($res = mysqli_fetch_array($rslt))
            {


                  echo "<option  value=".$res['id']."> ".$res['product_name']."</option>";
//                  echo "<input type='hidden' name='product_id' value=".$res['id']."/>";


//                 echo "<input type='hidden' name='product_id' value=".$res['id']."/>";


            }
            echo "</select>";


            ?>


            <div class="form-group">
                <input type="file" name="product_image" id="fileToUpload">
            </div>




            <div class="form-group form-check">
                <input type="checkbox" class="form-check-input" id="exampleCheck1">
                <label class="form-check-label" for="exampleCheck1">Check me out</label>
            </div>
            <button type="submit" class="btn btn-primary">Submit</button>
        </form></div>
</div>

</body>


<?php
include('include/script.php');
include ('include/footer.php');
?>
