<?php
include('include/header.php');
include('include/topbar.php');
?>

<?php
// including the database connection file
$con = mysqli_connect('localhost','root','');
mysqli_select_db($con,'corephpadmin');
//getting id from url
$id = $_GET['id'];

//selecting data associated with this particular id
$result = mysqli_query($con, "SELECT * FROM companies WHERE id=$id");

while($res = mysqli_fetch_array($result))
{
    $company_type = $res['company_type'];
    $company_name = $res['company_name'];
    $company_address = $res['company_address'];
    $company_phone = $res['company_phone'];
    $company_category = $res['company_category'];
    $slug = $res['slug'];
//    $status = $res['status'];

}
?>

<?php


if(isset($_POST['update']))
{

    $id = $_POST['id'];

    $company_type = $_POST['Company_type'];
    $company_name = $_POST['Company_name'];
    $company_address = $_POST['Company_address'];
    $company_phone = $_POST['Company_phone'];
    $company_category = $_POST['Company_category'];
    $slug = $_POST['Slug'];
    $status = $_POST['Status'];


    // checking empty fields
    if(empty($company_type) || empty($company_name) || empty($company_address) || empty($company_phone) || empty($company_category) || empty($slug)|| empty($status) )
    {

        if(empty($company_type)) {
            echo "<font color='red'>Company Type field is empty.</font><br/>";
        }

        if(empty($company_name)) {
            echo "<font color='red'>Company Name field is empty.</font><br/>";
        }

        if(empty($company_address)) {
            echo "<font color='red'>Company Address field is empty.</font><br/>";
        }
        if(empty($company_phone)) {
            echo "<font color='red'>Company Phone field is empty.</font><br/>";
        }

        if(empty($company_category)) {
            echo "<font color='red'>Company Category field is empty.</font><br/>";
        }

        if(empty($slug)) {
            echo "<font color='red'>Slug field is empty.</font><br/>";
        }

        if(empty($status)) {
            echo "<font color='red'>Status field is empty.</font><br/>";
        }

    } else {
        // if all the fields are filled (not empty)

        //insert data to database
//        $result = "INSERT INTO companies(company_type, company_name, company_address, company_phone, company_category,slug,status)
//        VALUES ('$company_type','$company_name','$company_address','$company_phone','$company_category','$slug', '$status')";


        //updating the table
        $result = "UPDATE companies SET company_type = '$company_type',company_name='$company_name',company_address='$company_address',company_phone='$company_phone',company_category='$company_category',slug='$slug',
        status='$status' WHERE id=$id";
        mysqli_query($con,$result);

        //redirectig to the display page. In our case, it is index.php
        header("Location:view_company.php");
    }
}
?>



<body id="page-top">

<!-- Page Wrapper -->
<div id="wrapper">
    <?php
    include('include/sidebar.php');
    ?>
    <div style="margin:auto; width: 80%;" class="col-md-5">
        <form action="edit_company.php" method="post">
            <div class="form-group">
                <label for="product_category">Company Type</label>
                <input type="text" class="form-control" id="product_category" name="Company_type" value="<?php echo $company_type; ?>" aria-describedby="emailHelp" placeholder="Enter Type">
            </div>
            <div class="form-group">
                <label for="product_name">Company Name</label>
                <input type="text" class="form-control" id="product_name" name="Company_name" value="<?php echo $company_name; ?>" aria-describedby="emailHelp" placeholder="Enter Company Name">
            </div>
            <div class="form-group">
                <label for="company_address">Company Address</label>
                <input type="text" class="form-control" id="company_address" name="Company_address" value="<?php echo $company_address; ?> " aria-describedby="emailHelp" placeholder="Enter Company Name">
            </div>
            <div class="form-group">
                <label for="company_phone">Company phone</label>
                <input type="text" class="form-control" id="company_phone" name="Company_phone" value="<?php echo $company_phone; ?>"   aria-describedby="emailHelp" placeholder="Enter Company Phone">
            </div>

            <div class="form-group">
                <label for="company_category">company_category</label>
                <input type="text" class="form-control" id="company_category" name="Company_category" value="<?php echo $company_category; ?>" aria-describedby="emailHelp" placeholder="Enter Company Category">
            </div>

            <div class="form-group">
                <label for="slug">slug</label>
                <input type="text" class="form-control" id="slug" name="Slug" value="<?php echo $slug; ?>" aria-describedby="emailHelp" placeholder="Enter Company Category">
            </div>

            <div class="form-group">
                <label for="exampleFormControlSelect1">Status</label>
                <select class="form-control" id="exampleFormControlSelect1" name="Status">
                    <option>Select</option>
                    <option value="ACTIVE">ACTIVE</option>
                    <option value="INACTIVE">INACTIVE</option>
                    <option value="PENDING">PENDING</option>
                    <option value="SUSPENDED">SUSPENDED</option>
                </select>
            </div>



            <div class="form-group form-check">
                <input type="checkbox" class="form-check-input" id="exampleCheck1">
                <label class="form-check-label" for="exampleCheck1">Check me out</label>
            </div>
            <input type="hidden" name="id" value=<?php echo $_GET['id'];?>>
            <input type="submit" name="update" class="btn btn-primary"/>
        </form></div>
</div>

</body>


<?php
include('include/script.php');
include ('include/footer.php');
?>
