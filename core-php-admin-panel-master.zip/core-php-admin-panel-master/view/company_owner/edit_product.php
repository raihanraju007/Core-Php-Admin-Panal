<?php
include('include/header.php');
include('include/topbar.php');
?>

<?php
// including the database connection file
$con = mysqli_connect('localhost','root','');
mysqli_select_db($con,'corephpadmin');
//getting id from url
$id = $_GET['id'];

//selecting data associated with this particular id
$result = mysqli_query($con, "SELECT * FROM products WHERE id=$id");

while($res = mysqli_fetch_array($result))
{
    $product_category = $res['product_category'];
    $product_name = $res['product_name'];
    $product_description = $res['product_description'];
    $generic_name = $res['generic_name'];
    $slug = $res['slug'];
//    $status = $res['status'];

}
?>

<?php


if(isset($_POST['update']))
{

    $id = $_POST['id'];

    $product_category = $_POST['Product_category'];
    $product_name = $_POST['Product_name'];
    $product_desc = $_POST['Product_description'];
    $product_generic = $_POST['Product_generic'];
    $product_slug = $_POST['Product_slug'];
    $product_status = $_POST['Status'];
    $price = $_POST['Price'];
    $featured = $_POST['Featured'];
    $specification = $_POST['Specification'];
    $contract = $_POST['Contract'];
    $link = $_POST['Link'];




    // checking empty fields
    if(empty($product_category) || empty($product_name) || empty($product_desc) || empty($product_generic) || empty($product_slug)
        || empty($product_status) || empty($price) || empty($featured) || empty($specification) || empty($contract) || empty($link))
    {

        if(empty($product_category)) {
            echo "<font color='red'>category field is empty.</font><br/>";
        }

        if(empty($product_name)) {
            echo "<font color='red'>name field is empty.</font><br/>";
        }

        if(empty($product_desc)) {
            echo "<font color='red'>description field is empty.</font><br/>";
        }
        if(empty($product_generic)) {
            echo "<font color='red'>generic name field is empty.</font><br/>";
        }

        if(empty($product_slug)) {
            echo "<font color='red'>slug field is empty.</font><br/>";
        }
        if(empty($product_status)) {
            echo "<font color='red'>Status field is empty.</font><br/>";
        }
        if(empty($price)) {
            echo "<font color='red'>Price field is empty.</font><br/>";
        }
        if(empty($featured)) {
            echo "<font color='red'>Featured field is empty.</font><br/>";
        }
        if(empty($specification )) {
            echo "<font color='red'>Specification  field is empty.</font><br/>";
        }
        if(empty($contract )) {
            echo "<font color='red'>contract field is empty.</font><br/>";
        }
        if(empty($link )) {
            echo "<font color='red'>Link field is empty.</font><br/>";
        }

    } else
        {

        //updating the table
        $result = "UPDATE products SET product_category = '$product_category',product_name='$product_name',product_description='$product_desc',generic_name='$product_generic',slug='$product_slug',
        status='$product_status',price='$price',featured='$featured',specification='$specification',contract='$contract',link='$link' WHERE id=$id";
        mysqli_query($con,$result);

        //redirectig to the display page. In our case, it is index.php
        header("Location:view_product.php");
    }
}
?>



<body id="page-top">

<!-- Page Wrapper -->
<div id="wrapper">
    <?php
    include('include/sidebar.php');
    ?>
    <div style="margin:auto; width: 80%;" class="col-md-5">
        <form action="edit_product.php" method="post">
            <div class="form-group">
                <label for="product_category">Product Category</label>
                <input type="text" class="form-control" id="product_category" name="Product_category" value="<?php echo $product_category; ?>" aria-describedby="emailHelp" placeholder="Enter category">
            </div>
            <div class="form-group">
                <label for="product_name">Product Name</label>
                <input type="text" class="form-control" id="product_name" name="Product_name" value="<?php echo $product_name; ?>" aria-describedby="emailHelp" placeholder="Enter product name">
            </div>
            <div class="form-group">
                <label for="product_description">Product Description</label>
                <input type="text" class="form-control" id="product_description" name="Product_description" value="<?php echo $product_description; ?> " aria-describedby="emailHelp" placeholder="Enter product description">
            </div>
            <div class="form-group">
                <label for="product_generic">Generic Name</label>
                <input type="text" class="form-control" id="product_generic" name="Product_generic" value="<?php echo $slug; ?>"   aria-describedby="emailHelp" placeholder="Enter generic name">
            </div>
            <div class="form-group">
                <label for="product_slug">Slug Name</label>
                <input type="text" class="form-control" id="product_slug" name="Product_slug" value="<?php echo $generic_name; ?>" aria-describedby="emailHelp" placeholder="Enter slug name">
            </div>
            <div class="form-group">
                <label for="exampleFormControlSelect1">Status</label>
                <select class="form-control" id="exampleFormControlSelect1" name="Status">
                    <option>Select</option>
                    <option value="ACTIVE">ACTIVE</option>
                    <option value="INACTIVE">INACTIVE</option>
                    <option value="PENDING">PENDING</option>
                    <option VALUE="DELETED">DELETED</option>
                </select>
            </div>

            <div class="form-group">
                <label for="price">Price</label>
                <input type="text" class="form-control" id="price" name="Price" value="<?php echo $price; ?>" aria-describedby="emailHelp" placeholder="Enter Price">
            </div>

            <div class="form-group">
                <label for="featured">Featured</label>
                <input type="text" class="form-control" id="featured" name="Featured" value="<?php echo $featured; ?>" aria-describedby="emailHelp" placeholder="Enter Featured">
            </div>

            <div class="form-group">
                <label for="specification">Specification</label>
                <input type="text" class="form-control" id="specification" name="Specification" value="<?php echo $specification; ?>" aria-describedby="emailHelp" placeholder="Enter Specification">
            </div>

            <div class="form-group">
                <label for="contract">Contract</label>
                <input type="text" class="form-control" id="contract" name="Contract" value="<?php echo $contract; ?>" aria-describedby="emailHelp" placeholder="Enter Contract">
            </div>

            <div class="form-group">
                <label for="link">Link</label>
                <input type="text" class="form-control" id="link" name="Link" value="<?php echo $link; ?>" aria-describedby="emailHelp" placeholder="Enter Link">
            </div>



            <div class="form-group form-check">
                <input type="checkbox" class="form-check-input" id="exampleCheck1">
                <label class="form-check-label" for="exampleCheck1">Check me out</label>
            </div>
            <input type="hidden" name="id" value=<?php echo $_GET['id'];?>>
            <input type="submit" name="update" class="btn btn-primary"/>
        </form></div>
</div>

</body>


<?php
include('include/script.php');
include ('include/footer.php');
?>
