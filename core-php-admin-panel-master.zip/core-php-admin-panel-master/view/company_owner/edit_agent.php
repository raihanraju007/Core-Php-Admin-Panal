<?php
include('include/header.php');
include('include/topbar.php');
?>

<?php
// including the database connection file
$con = mysqli_connect('localhost','root','');
mysqli_select_db($con,'corephpadmin');
//getting id from url
$id = $_GET['id'];

//selecting data associated with this particular id
$result = mysqli_query($con, "SELECT * FROM users WHERE id=$id");

while($res = mysqli_fetch_array($result))
{
    $user_name = $res['user_name'];
    $password= $res['password'];
    $email = $res['email'];
    $type = $res['type'];
    $company_id = $res['company_id'];
    $status = $res['status'];
//    $status = $res['status'];

}
?>

<?php


if(isset($_POST['update']))
{

    $id = $_POST['id'];

    $user_name = $_POST['User_name'];
    $password = $_POST['Password'];
    $email = $_POST['Email'];
    $type = $_POST['Type'];
    $company_id = $_POST['Company_id'];
    $status = $_POST['Status'];


//    $user_id =$_SESSION['user_id'];


    // checking empty fields
    if(empty($user_name) || empty($password) || empty($email) || empty($type) || empty($company_id) || empty($status) )
    {

        if(empty($user_name)) {
            echo "<font color='red'>User Type field is empty.</font><br/>";
        }

        if(empty($password)) {
            echo "<font color='red'>Password field is empty.</font><br/>";
        }

        if(empty($email)) {
            echo "<font color='red'>Email field is empty.</font><br/>";
        }
        if(empty($type)) {
            echo "<font color='red'>Type field is empty.</font><br/>";
        }

        if(empty($company_id)) {
            echo "<font color='red'>Company field is empty.</font><br/>";
        }

        if(empty($status)) {
            echo "<font color='red'>Status field is empty.</font><br/>";
        }

    } else {

        //updating the table
        $result = "UPDATE users SET user_name = '$user_name',password='$password',email='$email',type='$type',company_id='$company_id',status='$status'updated_on='' WHERE id=$id";
        mysqli_query($con,$result);

        //redirectig to the display page. In our case, it is index.php
        header("Location:view_agent.php");
    }
}
?>



<body id="page-top">

<!-- Page Wrapper -->
<div id="wrapper">
    <?php
    include('include/sidebar.php');
    ?>
    <div style="margin:auto; width: 80%;" class="col-md-5">
        <form action="edit_agent.php" method="post">
            <div class="form-group">
                <label for="user_name">User Name</label>
                <input type="text" class="form-control" id="user_name" name="User_name" value="<?php echo $user_name; ?>" aria-describedby="emailHelp" placeholder="Enter User Name">
            </div>
            <div class="form-group">
                <label for="password">Password</label>
                <input type="text" class="form-control" id="password" name="Password" value="<?php echo $password; ?>" aria-describedby="emailHelp" placeholder="Enter Password">
            </div>
            <div class="form-group">
                <label for="email">Email</label>
                <input type="email" class="form-control" id="email" name="Email" value="<?php echo $email; ?> " aria-describedby="emailHelp" placeholder="Enter Email">
            </div>

            <div class="form-group">
                <label for="exampleFormControlSelect1">Type</label>
                <select class="form-control" id="exampleFormControlSelect1" name="Type">
                    <option>Select</option>
                    <option value="AGENT">AGENT</option>

                </select>
            </div>

            <div class="form-group">
                <label for="company_id">Company ID</label>
                <input type="text" class="form-control" id="company_id" name="Company_id" value="<?php echo $company_id; ?>" aria-describedby="emailHelp" placeholder="Enter Company ID">
            </div>



            <div class="form-group">
                <label for="exampleFormControlSelect1">Status</label>
                <select class="form-control" id="exampleFormControlSelect1" name="Status">
                    <option>Select</option>
                    <option value="ACTIVE">ACTIVE</option>
                    <option value="INACTIVE">INACTIVE</option>
                    <option value="DELETED">DELETED</option>

                </select>
            </div>



            <div class="form-group form-check">
                <input type="checkbox" class="form-check-input" id="exampleCheck1">
                <label class="form-check-label" for="exampleCheck1">Check me out</label>
            </div>
            <input type="hidden" name="id" value=<?php echo $_GET['id'];?>>
            <input type="submit" name="update" class="btn btn-primary"/>
        </form></div>
</div>

</body>


<?php
include('include/script.php');
include ('include/footer.php');
?>
