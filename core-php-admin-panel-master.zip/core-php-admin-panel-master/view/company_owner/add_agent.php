<?php
include('include/header.php');
include('include/topbar.php');
?>


<?php
//including the database connection file
$con = mysqli_connect('localhost','root','');
mysqli_select_db($con,'corephpadmin');


if(isset($_POST['User_name']))
{

    $user_name = $_POST['User_name'];
    $password = $_POST['Password'];
    $email = $_POST['Email'];
    $type = $_POST['Type'];
    $company_id = $_POST['Company_id'];
    $status = $_POST['Status'];


//    $user_id =$_SESSION['user_id'];


    // checking empty fields
    if(empty($user_name) || empty($password) || empty($email) || empty($type) || empty($company_id) || empty($status) )
    {

        if(empty($user_name)) {
            echo "<font color='red'>User Type field is empty.</font><br/>";
        }

        if(empty($password)) {
            echo "<font color='red'>Password field is empty.</font><br/>";
        }

        if(empty($email)) {
            echo "<font color='red'>Email field is empty.</font><br/>";
        }
        if(empty($type)) {
            echo "<font color='red'>Type field is empty.</font><br/>";
        }

        if(empty($company_id)) {
            echo "<font color='red'>Company field is empty.</font><br/>";
        }

        if(empty($status)) {
            echo "<font color='red'>Status field is empty.</font><br/>";
        }

    } else {
        // if all the fields are filled (not empty)

        //insert data to database
        $sql = "INSERT INTO users(user_name, password, email,type,status,updated_on) 
        VALUES ('$user_name','$password','$email','$type','$company_id', '$status')";


        $rslt = mysqli_query($con,$sql);

        if($rslt)
        {

            //display success message
            echo "<font color='green'>Data added successfully.";
            echo "<br/><a href='view_company.php'>View Result</a>";
        }else{
            echo mysqli_error($con);
        }
    }
}
?>


<body id="page-top">

<!-- Page Wrapper -->
<div id="wrapper">
    <?php
    include('include/sidebar.php');
    ?>
    <div style="margin:auto; width: 80%;" class="col-md-5">
        <form action="add_agent.php" method="post">

            <div class="form-group">
                <label for="user_name">User Name</label>
                <input type="text" class="form-control" id="user_name" name="User_name" aria-describedby="emailHelp" placeholder="Enter User Name">
            </div>
            <div class="form-group">
                <label for="password">Password</label>
                <input type="text" class="form-control" id="password" name="Password" aria-describedby="emailHelp" placeholder="Enter Password">
            </div>
            <div class="form-group">
                <label for="email">Email</label>
                <input type="email" class="form-control" id="email" name="Email" aria-describedby="emailHelp" placeholder="Enter Email">
            </div>

            <div class="form-group">
                <label for="exampleFormControlSelect1">User Type</label>
                <select class="form-control" id="exampleFormControlSelect1" name="Type">
                    <option>Select</option>
                    <option value="AGENT">AGENT</option>
                </select>
            </div>


            <div class="form-group">
                <label for="company_id">Company ID</label>
                <input type="text" class="form-control" id="company_phone" name="Company_id"  aria-describedby="emailHelp" placeholder="Enter Company Phone">



            <div class="form-group">
                <label for="exampleFormControlSelect1">Status</label>
                <select class="form-control" id="exampleFormControlSelect1" name="Status">
                    <option>Select</option>
                    <option value="ACTIVE">ACTIVE</option>
                    <option value="INACTIVE">INACTIVE</option>
                    <option VALUE="DELETED">DELETED</option>
                </select>
            </div>

            <div class="form-group form-check">
                <input type="checkbox" class="form-check-input" id="exampleCheck1">
                <label class="form-check-label" for="exampleCheck1">Check me out</label>
            </div>
            <button type="submit" class="btn btn-primary">Submit</button>
        </form></div>
</div>

</body>


<?php
include('include/script.php');
include ('include/footer.php');
?>
