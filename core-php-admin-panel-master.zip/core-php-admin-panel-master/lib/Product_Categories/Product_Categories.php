<?php


class Product_Categories
{
    public function __construct()
    {
    }

    /**
     *
     */
    public function __destruct()
    {
    }

}