<?php


class Brands
{

    public function __construct()
    {
    }

    /**
     *
     */
    public function __destruct()
    {
    }

}