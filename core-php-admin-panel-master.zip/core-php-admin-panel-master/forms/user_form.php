<fieldset>
    <?php
    if($edit){
        ?>
        <input type="hidden" name="id"  value="<?php echo $users_id ?>" class="form-control"  id = "user_id" >
    <?php }
    ?>
    <div class="form-group">
        <label for="f_name">User Name</label>
        <input type="text" name="user_name" placeholder="User Name" value="<?php echo htmlspecialchars($edit ? $users['user_name'] : '', ENT_QUOTES, 'UTF-8'); ?>" class="form-control" required="required" id = "user_name" >
    </div>

    <div class="form-group">
        <label for="f_name">Password</label>
        <input type="text" name="password" placeholder="Password" value="<?php echo htmlspecialchars($edit ? $users['password'] : '', ENT_QUOTES, 'UTF-8'); ?>" class="form-control" required="required" id = "password" >
    </div>


<!--    <div class="form-group">-->
<!--        <label for="address">Company Address</label>-->
<!--        <textarea name="company_address" placeholder="Company Address" class="form-control" id="company_address">--><?php //echo htmlspecialchars($edit ? $companies['company_address'] : '', ENT_QUOTES, 'UTF-8'); ?><!--</textarea>-->
<!--    </div>-->

    <div class="form-group">
        <label for="f_name">Email</label>
        <input type="email" name="email" placeholder="Email" value="<?php echo htmlspecialchars($edit ? $users['email'] : '', ENT_QUOTES, 'UTF-8'); ?>" class="form-control" required="required" id = "email" >
    </div>

    <div class="form-group">
        <label>Users Type</label>
        <?php $opt_arr = array("ROOT", "COMPANY_OWNER", "ADMIN", "AGENT");
        ?>
        <select name="type" class="form-control selectpicker" required>
            <option value="ROOT">ROOT</option>
            <option value="COMPANY_OWNER">COMPANY_OWNER</option>
            <option value="ADMIN">ADMIN</option>
            <option value="AGENT">AGENT</option>

        </select>
    </div>

    <div class="form-group">
        <label for="f_name">company id</label>
        <input type="text" name="company_id" placeholder="company id" value="<?php echo htmlspecialchars($edit ? $users['company_id'] : '', ENT_QUOTES, 'UTF-8'); ?>" class="form-control" required="required" id = "company_id" >
    </div>

    <div class="form-group">
        <label>Status </label>
        <?php $opt_arr = array("ACTIVE", "INACTIVE", "DELETED", "SUSPENDED");
        ?>
        <select name="status" class="form-control selectpicker" required>
            <option value="ACTIVE" >ACTIVE</option>
            <option value="INACTIVE" >INACTIVE</option>
            <option value="ACTIVE" >DELETED</option>
            <option value="ACTIVE" >SUSPENDED</option>
        </select>
    </div>


    <div class="form-group text-center">
        <label></label>
        <button type="submit" class="btn btn-warning" >Save <span class="glyphicon glyphicon-send"></span></button>
    </div>
</fieldset>
