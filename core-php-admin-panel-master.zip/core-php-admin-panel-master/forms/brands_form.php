<fieldset>
    <?php
    if($edit){
        ?>
        <input type="hidden" name="id"  value="<?php echo $brands_id ?>" class="form-control"  id = "brand_id" >
    <?php }
    ?>
    <div class="form-group">
        <label for="f_name">Brand Type</label>
        <input type="text" name="brand_type" placeholder="Company Type" value="<?php echo htmlspecialchars($edit ? $brands['brand_type'] : '', ENT_QUOTES, 'UTF-8'); ?>" class="form-control" required="required" id = "brand_type" >
    </div>

    <div class="form-group">
        <label for="f_name">Company Name</label>
        <input type="text" name="brand_name" placeholder="Brand Name" value="<?php echo htmlspecialchars($edit ? $brands['brand_name'] : '', ENT_QUOTES, 'UTF-8'); ?>" class="form-control" required="required" id = "brand_name" >
    </div>


    <div class="form-group">
        <label for="address">Brand Address</label>
        <textarea name="brand_address" placeholder="Brand Address" class="form-control" id="brand_address"><?php echo htmlspecialchars($edit ? $brands['brand_address'] : '', ENT_QUOTES, 'UTF-8'); ?></textarea>
    </div>

    <div class="form-group">
        <label for="f_name">Brand Phone</label>
        <input type="text" name="brand_phone" placeholder="Brand Phone" value="<?php echo htmlspecialchars($edit ? $brands['brand_phone'] : '', ENT_QUOTES, 'UTF-8'); ?>" class="form-control" required="required" id = "brand_phone" >
    </div>

    <div class="form-group">
        <label>Brand Category </label>
        <?php $opt_arr = array("REGULAR", "SILVER", "GOLD", "DIAMOND");
        ?>
        <select name="brand_category" class="form-control selectpicker" required>
            <option value="REGULAR">REGULAR</option>
            <option value="SILVER">SILVER</option>
            <option value="GOLD">GOLD</option>
            <option value="DIAMOND">DIAMOND</option>

        </select>
    </div>

    <div class="form-group">
        <label for="f_name">Slug</label>
        <input type="text" name="slug" placeholder="Slug" value="<?php echo htmlspecialchars($edit ? $brands['slug'] : '', ENT_QUOTES, 'UTF-8'); ?>" class="form-control" required="required" id = "Slug" >
    </div>

    <div class="form-group">
        <label>Status </label>
        <?php $opt_arr = array("ACTIVE", "INACTIVE", "DELETED", "SUSPENDED");
        ?>
        <select name="status" class="form-control selectpicker" required>
            <option value="ACTIVE" >ACTIVE</option>
            <option value="INACTIVE" >INACTIVE</option>
            <option value="ACTIVE" >DELETED</option>
            <option value="ACTIVE" >SUSPENDED</option>
        </select>
    </div>


    <div class="form-group text-center">
        <label></label>
        <button type="submit" class="btn btn-warning" >Save <span class="glyphicon glyphicon-send"></span></button>
    </div>
</fieldset>
