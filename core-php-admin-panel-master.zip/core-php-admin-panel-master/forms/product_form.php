<fieldset>
    <?php
    if($edit){
        ?>
        <input type="hidden" name="id"  value="<?php echo $products_id ?>" class="form-control"  id = "product_id" >
    <?php }
    ?>
    <div class="form-group">
        <label for="f_name">Product Category</label>
        <input type="text" name="product_category" placeholder="Product Category" value="<?php echo htmlspecialchars($edit ? $products['product_category'] : '', ENT_QUOTES, 'UTF-8'); ?>" class="form-control" required="required" id = "product_category" >
    </div>

    <div class="form-group">
        <label for="f_name">Product Name</label>
        <input type="text" name="product_name" placeholder="Product Name" value="<?php echo htmlspecialchars($edit ? $products['product_name'] : '', ENT_QUOTES, 'UTF-8'); ?>" class="form-control" required="required" id = "product_name" >
    </div>


    <div class="form-group">
        <label for="address">Product Description</label>
        <textarea name="product_description" placeholder="Product Description" class="form-control" id="product_description"><?php echo htmlspecialchars($edit ? $products['product_description'] : '', ENT_QUOTES, 'UTF-8'); ?></textarea>
    </div>

    <div class="form-group">
        <label for="f_name"> Generic Name </label>
        <input type="text" name="generic_name" placeholder="Generic Name" value="<?php echo htmlspecialchars($edit ? $products['generic_name'] : '', ENT_QUOTES, 'UTF-8'); ?>" class="form-control" required="required" id = "generic_name" >
    </div>

    <div class="form-group">
        <label for="f_name">Slug</label>
        <input type="text" name="slug" placeholder="Slug" value="<?php echo htmlspecialchars($edit ? $products['slug'] : '', ENT_QUOTES, 'UTF-8'); ?>" class="form-control" required="required" id = "Slug" >
    </div>

    <div class="form-group">
        <label>Status </label>
        <?php $opt_arr = array("ACTIVE", "INACTIVE", "PENDING", "DELETED");
        ?>
        <select name="status" class="form-control selectpicker" required>
            <option value="ACTIVE" >ACTIVE</option>
            <option value="INACTIVE">INACTIVE</option>
            <option value="ACTIVE" >PENDING</option>
            <option value="ACTIVE" >DELETED</option>
        </select>
    </div>


    <div class="form-group text-center">
        <label></label>
        <button type="submit" class="btn btn-warning" >Save <span class="glyphicon glyphicon-send"></span></button>
    </div>
</fieldset>
