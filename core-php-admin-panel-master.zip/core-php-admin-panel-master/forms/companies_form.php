<fieldset>
    <?php
        if($edit){
            ?>
            <input type="hidden" name="id"  value="<?php echo $companies_id ?>" class="form-control"  id = "company_id" >
       <?php }
    ?>
    <div class="form-group">
        <label for="f_name">Company Type</label>
        <input type="text" name="company_type" placeholder="Company Type" value="<?php echo htmlspecialchars($edit ? $companies['company_type'] : '', ENT_QUOTES, 'UTF-8'); ?>" class="form-control" required="required" id = "company_type" >
    </div>

    <div class="form-group">
        <label for="f_name">Company Name</label>
        <input type="text" name="company_name" placeholder="Company Name" value="<?php echo htmlspecialchars($edit ? $companies['company_name'] : '', ENT_QUOTES, 'UTF-8'); ?>" class="form-control" required="required" id = "company_name" >
    </div>


    <div class="form-group">
        <label for="address">Company Address</label>
        <textarea name="company_address" placeholder="Company Address" class="form-control" id="company_address"><?php echo htmlspecialchars($edit ? $companies['company_address'] : '', ENT_QUOTES, 'UTF-8'); ?></textarea>
    </div>

    <div class="form-group">
        <label for="f_name">Company Phone</label>
        <input type="text" name="company_phone" placeholder="Company Phone" value="<?php echo htmlspecialchars($edit ? $companies['company_phone'] : '', ENT_QUOTES, 'UTF-8'); ?>" class="form-control" required="required" id = "company_phone" >
    </div>

    <div class="form-group">
        <label>Company Category </label>
        <?php $opt_arr = array("REGULAR", "SILVER", "GOLD", "DIAMOND");
        ?>
        <select name="company_category" class="form-control selectpicker" required>
            <option value="REGULAR">REGULAR</option>
            <option value="SILVER">SILVER</option>
            <option value="GOLD">GOLD</option>
            <option value="DIAMOND">DIAMOND</option>

        </select>
    </div>

    <div class="form-group">
        <label for="f_name">Slug</label>
        <input type="text" name="slug" placeholder="Slug" value="<?php echo htmlspecialchars($edit ? $companies['slug'] : '', ENT_QUOTES, 'UTF-8'); ?>" class="form-control" required="required" id = "Slug" >
    </div>

    <div class="form-group">
        <label>Status </label>
        <?php $opt_arr = array("ACTIVE", "INACTIVE", "DELETED", "SUSPENDED");
        ?>
        <select name="status" class="form-control selectpicker" required>
            <option value="ACTIVE" >ACTIVE</option>
            <option value="INACTIVE" >INACTIVE</option>
            <option value="ACTIVE" >DELETED</option>
            <option value="ACTIVE" >SUSPENDED</option>
        </select>
    </div>


    <div class="form-group text-center">
        <label></label>
        <button type="submit" class="btn btn-warning" >Save <span class="glyphicon glyphicon-send"></span></button>
    </div>
</fieldset>
