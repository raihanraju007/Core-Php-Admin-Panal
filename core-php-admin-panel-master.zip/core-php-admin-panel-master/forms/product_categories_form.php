<fieldset>
    <?php
    if($edit){
        ?>
        <input type="hidden" name="id"  value="<?php echo $product_categories_id ?>" class="form-control"  id = "product_categories_id" >
    <?php }
    ?>
    <div class="form-group">
        <label for="f_name">Category Name</label>
        <input type="text" name="category_name" placeholder="Category" value="<?php echo htmlspecialchars($edit ? $product_categories['category_name'] : '', ENT_QUOTES, 'UTF-8'); ?>" class="form-control" required="required" id = "category_name" >
    </div>


    <div class="form-group">
        <label for="address">Category Description</label>
        <textarea name="category_description" placeholder="Category Description" class="form-control" id="category_description"><?php echo htmlspecialchars($edit ? $product_categories['category_description'] : '', ENT_QUOTES, 'UTF-8'); ?></textarea>
    </div>


    <div class="form-group">
        <label>Status </label>
        <?php $opt_arr = array("ACTIVE", "INACTIVE", "DELETED");
        ?>
        <select name="status" class="form-control selectpicker" required>
            <option value="ACTIVE" >ACTIVE</option>
            <option value="INACTIVE" >INACTIVE</option>
            <option value="ACTIVE" >DELETED</option>
        </select>
    </div>


    <div class="form-group text-center">
        <label></label>
        <button type="submit" class="btn btn-warning" >Save <span class="glyphicon glyphicon-send"></span></button>
    </div>
</fieldset>
