-- phpMyAdmin SQL Dump
-- version 4.9.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Mar 21, 2021 at 08:30 AM
-- Server version: 10.4.8-MariaDB
-- PHP Version: 7.3.11

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `corephpadmin`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin_accounts`
--

CREATE TABLE `admin_accounts` (
  `id` int(25) NOT NULL,
  `user_name` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  `series_id` varchar(60) DEFAULT NULL,
  `remember_token` varchar(255) DEFAULT NULL,
  `expires` datetime DEFAULT NULL,
  `admin_type` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin_accounts`
--

INSERT INTO `admin_accounts` (`id`, `user_name`, `password`, `series_id`, `remember_token`, `expires`, `admin_type`) VALUES
(4, 'superadmin', '$2y$10$eo7.w0Ttuy8mOBMvDlGqDeewQERkXu//7qO3jXp5NC76LwfAZpNrO', 'rvuWJHMd5LTxLC2J', '$2y$10$LDUi4w/UAM2PgfMoKkLo4.igJX39G5/WQOEDHRaDy3y2KZeIxXggm', '2019-02-16 22:39:57', 'super'),
(7, 'anand', '$2y$10$OrQFRZdSUP3X2kvGZrg.zeplQkxcJAq1s6atRehyCpbEvOVPu8KPe', NULL, NULL, NULL, 'admin'),
(8, 'admin', '$2y$10$RnDwpen5c8.gtZLaxHEHDOKWY77t/20A4RRkWBsjlPuu7Wmy0HyBu', 'MyG5Xw2I12EWdJeD', '$2y$10$XL/RhpCz.uQoWE1xV77Wje4I4ker.gtg7YV4yqNwLZfzIYnP7E8Na', '2019-08-22 01:12:33', 'admin');

-- --------------------------------------------------------

--
-- Table structure for table `brands`
--

CREATE TABLE `brands` (
  `id` int(10) UNSIGNED NOT NULL,
  `brand_type` varchar(100) NOT NULL COMMENT 'Electronic, Textile',
  `brand_name` varchar(100) NOT NULL,
  `brand_address` varchar(200) NOT NULL,
  `brand_phone` varchar(20) NOT NULL,
  `brand_category` enum('REGULAR','SILVER','GOLD','DIAMOND') NOT NULL DEFAULT 'REGULAR',
  `slug` varchar(100) NOT NULL,
  `status` enum('ACTIVE','INACTIVE','DELETED','SUSPENDED') NOT NULL DEFAULT 'INACTIVE'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `brands`
--

INSERT INTO `brands` (`id`, `brand_type`, `brand_name`, `brand_address`, `brand_phone`, `brand_category`, `slug`, `status`) VALUES
(1, 'Shoes', 'Bata', 'Gazipur', '78965262', 'REGULAR', 'B', 'ACTIVE'),
(2, 'IT & Education', 'Sheba', 'Dhonmondi', '1234567890', 'REGULAR', 'AS', 'INACTIVE'),
(4, 'All Education', 'PNT', 'Panthopoth', '12345678', 'GOLD', 'PNT ', 'ACTIVE');

-- --------------------------------------------------------

--
-- Table structure for table `companies`
--

CREATE TABLE `companies` (
  `id` int(10) UNSIGNED NOT NULL,
  `company_type` varchar(100) NOT NULL,
  `company_name` varchar(100) NOT NULL,
  `company_address` varchar(200) NOT NULL,
  `company_phone` varchar(20) NOT NULL,
  `company_category` enum('REGULAR','SILVER','GOLD','DIAMOND') NOT NULL DEFAULT 'REGULAR',
  `slug` varchar(100) NOT NULL,
  `status` enum('ACTIVE','INACTIVE','DELETED','SUSPENDED') NOT NULL DEFAULT 'INACTIVE'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `companies`
--

INSERT INTO `companies` (`id`, `company_type`, `company_name`, `company_address`, `company_phone`, `company_category`, `slug`, `status`) VALUES
(1, 'IT Service', 'AHC co. ltd', 'Dhonmondi ', '0184723452', 'REGULAR', '123', 'ACTIVE'),
(2, 'Education', 'Daffodil Group', 'Dhaka bangladesh', '1234567890', 'REGULAR', 'dcl', 'ACTIVE'),
(3, 'English Language Development Center', 'Wings Learning Center', 'Dhanmondi 4 a', '123456789', 'DIAMOND', 'WLC', 'ACTIVE'),
(5, 'Education', 'Wings Learning Center', 'Dhonmondi ', '01740387029', 'REGULAR', 'WLC', 'ACTIVE'),
(6, 'Export Import', 'xyz', 'asdfghj', '1234567', '', 'asdf', 'ACTIVE');

-- --------------------------------------------------------

--
-- Table structure for table `customers`
--

CREATE TABLE `customers` (
  `id` int(10) NOT NULL,
  `f_name` varchar(25) NOT NULL,
  `l_name` varchar(25) NOT NULL,
  `gender` varchar(6) DEFAULT NULL,
  `address` varchar(100) DEFAULT NULL,
  `city` varchar(15) DEFAULT NULL,
  `state` varchar(30) DEFAULT NULL,
  `phone` varchar(15) DEFAULT NULL,
  `email` varchar(50) DEFAULT NULL,
  `date_of_birth` date DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `customers`
--

INSERT INTO `customers` (`id`, `f_name`, `l_name`, `gender`, `address`, `city`, `state`, `phone`, `email`, `date_of_birth`, `created_at`, `updated_at`) VALUES
(4, 'Md Raihan ', 'Hossin', 'male', 'dhaka', NULL, 'Kerala', '123456', 'raju@gmail.com', '2021-03-11', '2021-03-11 05:09:55', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `employees`
--

CREATE TABLE `employees` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `address` varchar(255) NOT NULL,
  `salary` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `employees`
--

INSERT INTO `employees` (`id`, `name`, `address`, `salary`) VALUES
(1, 'Md Raihan Hossin Raju', 'Dhaka Bangladesh', 30000),
(2, 'xyz', 'Rajshahi', 10000),
(3, 'Milon Mahmud', 'Naogaon', 123456789);

-- --------------------------------------------------------

--
-- Table structure for table `gallery`
--

CREATE TABLE `gallery` (
  `id` int(11) NOT NULL,
  `product_pic` varchar(200) NOT NULL,
  `product_id` int(10) UNSIGNED DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `gallery`
--

INSERT INTO `gallery` (`id`, `product_pic`, `product_id`) VALUES
(57, 'Capture.JPG', 3),
(56, 'Capture.JPG', 4),
(55, 'Capture.JPG', 5),
(58, 'photo.png', 5);

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `id` int(10) UNSIGNED NOT NULL,
  `product_category` varchar(100) NOT NULL,
  `product_name` varchar(100) NOT NULL,
  `product_description` text NOT NULL,
  `generic_name` varchar(50) NOT NULL,
  `slug` varchar(100) NOT NULL,
  `status` enum('ACTIVE','INACTIVE','PENDING','DELETED') NOT NULL,
  `price` int(11) DEFAULT NULL,
  `featured` varchar(255) DEFAULT NULL,
  `specification` varchar(255) DEFAULT NULL,
  `contract` varchar(255) DEFAULT NULL,
  `link` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`id`, `product_category`, `product_name`, `product_description`, `generic_name`, `slug`, `status`, `price`, `featured`, `specification`, `contract`, `link`) VALUES
(3, '123', 'rdxctfvygjbhuknjk', 'ftyguhjoikp', 'fyguhijok', 'vghbjnk', 'ACTIVE', NULL, NULL, NULL, NULL, NULL),
(4, 'First Product', 'Book', ' fbtbvd g t', 'cgcew', ' gwec', 'INACTIVE', NULL, NULL, NULL, NULL, NULL),
(5, 'Man Style', 'T Shirt', 'abcd', 'sdf sfsd', ' hbcdsbjsd', '', NULL, NULL, NULL, NULL, NULL),
(6, 'Woman Style', 'Shoes ', 'qwertyuiop', 'asdf', 'zxcv', 'INACTIVE', NULL, NULL, NULL, NULL, NULL),
(7, 'Man Style', 'T Shirt', 'Eid T Shirt', 'Man Fashion', 'MF', 'ACTIVE', 500, 'YES', 'it is aaaaafgshdj', '01740387029', 'www.sheba.com'),
(8, 'Man Style', 'T Shirt', 'Done', 'Man Fashion', 'MF', 'ACTIVE', 500, 'YES', 'aaaaaaa', '01740387029', 'www.sheba.com');

-- --------------------------------------------------------

--
-- Table structure for table `product_brand`
--

CREATE TABLE `product_brand` (
  `id` int(11) NOT NULL,
  `product_id` int(10) UNSIGNED DEFAULT NULL,
  `brand_id` int(10) UNSIGNED DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `product_brand`
--

INSERT INTO `product_brand` (`id`, `product_id`, `brand_id`) VALUES
(1, 3, 1);

-- --------------------------------------------------------

--
-- Table structure for table `product_categories`
--

CREATE TABLE `product_categories` (
  `id` int(10) UNSIGNED NOT NULL,
  `category_name` varchar(100) NOT NULL,
  `category_description` text NOT NULL,
  `status` enum('ACTIVE','INACTIVE','DELETED') NOT NULL DEFAULT 'ACTIVE'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `product_categories`
--

INSERT INTO `product_categories` (`id`, `category_name`, `category_description`, `status`) VALUES
(2, 'test', 'Check Category', 'INACTIVE'),
(3, 'test', 'dfghjklvbnm', 'ACTIVE');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(10) UNSIGNED NOT NULL,
  `user_name` varchar(30) NOT NULL,
  `password` varchar(50) NOT NULL,
  `email` varchar(100) NOT NULL,
  `type` enum('ROOT','COMPANY_OWNER','ADMIN','AGENT') NOT NULL DEFAULT 'AGENT',
  `company_id` int(11) DEFAULT NULL,
  `status` enum('ACTIVE','INACTIVE','DELETED') NOT NULL DEFAULT 'ACTIVE',
  `updated_on` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `user_name`, `password`, `email`, `type`, `company_id`, `status`, `updated_on`) VALUES
(1, 'Md Raihan Hossin', '123456', 'raihan@gmail.com', 'ROOT', 0, 'ACTIVE', '2021-03-14 10:16:36'),
(2, 'test User', '123456', 'vgfe@gmail.com', 'ROOT', 0, 'ACTIVE', '2021-03-14 10:17:23'),
(3, 'ROOT User', '123456', 'root@gmail.com', 'ROOT', 1, 'ACTIVE', '2021-03-14 10:43:27'),
(4, 'COMPANY_OWNER', '123456', 'companyOwner@gmail.com', 'COMPANY_OWNER', 2, 'ACTIVE', '2021-03-14 10:44:24'),
(5, 'ADMIN User', '123456', 'admin@gmail.com', 'ADMIN', 3, 'ACTIVE', '2021-03-14 10:45:14'),
(6, 'AGENT User', '123456', 'agent@gmail.com', 'AGENT', 4, 'ACTIVE', '2021-03-14 10:45:48'),
(7, 'selim', '123456', 'selim@gmail.com', 'AGENT', NULL, 'ACTIVE', '0000-00-00 00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `user_accounts`
--

CREATE TABLE `user_accounts` (
  `id` int(25) NOT NULL,
  `user_name` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  `series_id` varchar(60) DEFAULT NULL,
  `remember_token` varchar(255) DEFAULT NULL,
  `expires` datetime DEFAULT NULL,
  `user_type` enum('ROOT','COMPANY_OWNER','ADMIN','AGENT') NOT NULL DEFAULT 'AGENT'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user_accounts`
--

INSERT INTO `user_accounts` (`id`, `user_name`, `password`, `series_id`, `remember_token`, `expires`, `user_type`) VALUES
(4, 'superadmin', '$2y$10$eo7.w0Ttuy8mOBMvDlGqDeewQERkXu//7qO3jXp5NC76LwfAZpNrO', 'rvuWJHMd5LTxLC2J', '$2y$10$LDUi4w/UAM2PgfMoKkLo4.igJX39G5/WQOEDHRaDy3y2KZeIxXggm', '2019-02-16 22:39:57', 'ROOT'),
(7, 'anand', '$2y$10$OrQFRZdSUP3X2kvGZrg.zeplQkxcJAq1s6atRehyCpbEvOVPu8KPe', NULL, NULL, NULL, 'ADMIN'),
(8, 'admin', '$2y$10$RnDwpen5c8.gtZLaxHEHDOKWY77t/20A4RRkWBsjlPuu7Wmy0HyBu', 'ZCD6viHuEGD5ZsLy', '$2y$10$j4iC6deA6JGFoxeD3LDnSOk2TYSih8OdRML3z5vLb231ALXlMqZ/6', '2021-04-13 18:59:28', 'ADMIN'),
(9, 'agent', '$2y$10$RnDwpen5c8.gtZLaxHEHDOKWY77t/20A4RRkWBsjlPuu7Wmy0HyBu', 'zbD2C4Zl3CE4oy8a', '$2y$10$FLRgwT15AYFvHzDuFqNX5.xiM7qmb5iVLwFG12tD5eqJP/yYJbGfi', '2021-04-13 19:16:13', 'AGENT'),
(23, 'company_owner', '$2y$10$RnDwpen5c8.gtZLaxHEHDOKWY77t/20A4RRkWBsjlPuu7Wmy0HyBu', 'Rzs0ck7jNpRs2GIL', '$2y$10$KB7vJwSERBPfwc9Tf22WxO9kXzNCS/jqakkBYaGVIZ.0.T7IDuW5m', '2021-04-13 19:16:27', 'COMPANY_OWNER'),
(24, 'company_admin', '$2y$10$RnDwpen5c8.gtZLaxHEHDOKWY77t/20A4RRkWBsjlPuu7Wmy0HyBu', 'Pcy6w1AXxQHxNIkH', '$2y$10$OtJCUxDPCJt1sp7Z88Ts0uJv..OYrRerk94jRvT27.9fCzqrEnMQ2', '2021-04-13 19:16:47', 'ADMIN'),
(25, 'root', '$2y$10$RnDwpen5c8.gtZLaxHEHDOKWY77t/20A4RRkWBsjlPuu7Wmy0HyBu', 'OA7YvVLWY3l8qwes', '$2y$10$09VvOLI.9E9vhHAq.9vloOH0G81THSKIwHI6K1SD2zNdzG1Yvy4u2', '2021-04-13 19:15:56', 'ROOT');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin_accounts`
--
ALTER TABLE `admin_accounts`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `user_name` (`user_name`);

--
-- Indexes for table `brands`
--
ALTER TABLE `brands`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `companies`
--
ALTER TABLE `companies`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `customers`
--
ALTER TABLE `customers`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `employees`
--
ALTER TABLE `employees`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `gallery`
--
ALTER TABLE `gallery`
  ADD PRIMARY KEY (`id`),
  ADD KEY `product_id` (`product_id`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `product_brand`
--
ALTER TABLE `product_brand`
  ADD PRIMARY KEY (`id`),
  ADD KEY `product_id` (`product_id`),
  ADD KEY `brand_id` (`brand_id`);

--
-- Indexes for table `product_categories`
--
ALTER TABLE `product_categories`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user_accounts`
--
ALTER TABLE `user_accounts`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin_accounts`
--
ALTER TABLE `admin_accounts`
  MODIFY `id` int(25) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `brands`
--
ALTER TABLE `brands`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `companies`
--
ALTER TABLE `companies`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `customers`
--
ALTER TABLE `customers`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `employees`
--
ALTER TABLE `employees`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `gallery`
--
ALTER TABLE `gallery`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=59;

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `product_brand`
--
ALTER TABLE `product_brand`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `product_categories`
--
ALTER TABLE `product_categories`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `user_accounts`
--
ALTER TABLE `user_accounts`
  MODIFY `id` int(25) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=27;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `product_brand`
--
ALTER TABLE `product_brand`
  ADD CONSTRAINT `product_brand_ibfk_1` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`),
  ADD CONSTRAINT `product_brand_ibfk_2` FOREIGN KEY (`brand_id`) REFERENCES `brands` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
